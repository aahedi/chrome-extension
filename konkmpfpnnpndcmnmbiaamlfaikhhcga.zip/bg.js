
//#E33A11
function getword(info,tab) {
   console.log("info",info );
      console.log( "tab",tab);
       var sd= savedomain(tab.url,null,null,null,null,null,null)
      
    
       if(sd.status){
      	chrome.tabs.update(tab.id, {url:chrome.extension.getURL( "b.htm?url="+tab.url)});
      	reloadOptionpage();
      }
 }

function reloadOptionpage(){

	chrome.windows.getAll({populate:true},function(windows){
	  windows.forEach(function(window){
	    window.tabs.forEach(function(tab){
	      if(tab.url.toString().toLowerCase().indexOf("chrome-extension://"+chrome.app.getDetails().id+"/options.html")
	      	!=-1){
	      	chrome.tabs.reload(tab.id);
	      }
	      console.log(tab.url);
	    });
	  });
	});

}

function settingpage(){
	chrome.tabs.create({ 

        url: chrome.extension.getURL("options.html")
    })
}

var contexts = ["page","selection","link","editable","image","video",
                "audio"];

for (var i = 0; i < contexts.length; i++) {
  var context = contexts[i];
  var title = "Test '" + context + "' menu item";
  var parent =chrome.contextMenus.create({
                'title': chrome.app.getDetails().name,
                 
                "contexts":[context],
                 'onclick': getword
});
  var child1 = chrome.contextMenus.create(
  {"title": "Block this website [domain]", "parentId": parent, "onclick": getword,"contexts":[context]});
var child2 = chrome.contextMenus.create(
  {"title": "Setting Page", "parentId": parent, "onclick": settingpage,"contexts":[context]});

 
}

// var child1 = chrome.contextMenus.create(
//   {"title": "Child 1", "parentId": parent, "onclick": getword});
// var child2 = chrome.contextMenus.create(
//   {"title": "Child 2", "parentId": parent, "onclick": getword});
//console.log("parent:" + parent + " child1:" + child1 + " child2:" + child2);


 

 
//////////////context menu ends//////////////////////////////// 
chrome.webRequest.onBeforeRequest.addListener(
        function(details) { 

        if("running" in localStorage){
		    if( localStorage["running"]=="no"){
		    		return {cancel:false}
		    }
		}
		//console.log(details);
		var uri = new URI(details.url);

	     if(uri.protocol().toLowerCase()=="chrome-extension"){
	     		return {cancel:false}
	     }

	     if(uri.protocol().toLowerCase()=="chrome"){
	     	var chromhisunins=blockUninHistory(details.url);
	     		if(chromhisunins.block){
	     			return {redirectUrl:chrome.extension.getURL(chromhisunins.page)}
	     		}
	     }
		if( uri.hostname()!= ""){

				
				var block1= 	filter_domain(uri.hostname(),details.type,details.url,"block","instant",details.method,uri);
				var block2=	filter_page(details.url,details.type,details.url,"block","instant",details.method);
				if(block1.block||block2.block){//
						if(block2.url!=null && block2.url!="b.html" ){
					      return {redirectUrl:block2.url}
					    }
					    if(block1.url!=null && block1.url!="b.html" ){
					      return {redirectUrl:block1.url}
					    } 
						else{
					      return {redirectUrl:chrome.extension.getURL( "b.htm?url="+details.url)}
					    }
				}else{
					return {cancel:false}
				}

		}else{

				var block1=	filter_page(details.url,details.type,details.url,"block","instant",details.method);			
				if(block1.block){
					   if(block2.url!=null && block2.url!="b.html"){
					      return {redirectUrl:block2.url}
					    }else{
					      return {redirectUrl:chrome.extension.getURL( "b.htm?url="+details.url)}
					    }
						
				}else{
					return {cancel:false}
				}
		}
		
		
		/*
			    frameId: 45
				method: "GET"
				parentFrameId: 0
				requestId: "188507"
				tabId: 2189
				timeStamp: 1449478477583.206
				type: "xmlhttprequest"
				url: "https://m"

		*/
		return {cancel:false}
		//return {redirectUrl:chrome.extension.getURL( "b.htm?url="+details.url)}
		},
        {urls: ["*://*/*"],types: [ "xmlhttprequest","main_frame","sub_frame","image","script"]},
        ["blocking"]
        );

chrome.tabs.onUpdated.addListener(
        function(activeInfo,changeinfo,tab) {
        	console.log(tab);

        if("running" in localStorage){
		    if( localStorage["running"]=="no"){
		    		return false;
		    }
		}
            chrome.tabs.get(tab.id, processTab);
        });

chrome.tabs.onHighlighted.addListener(function(f){console.log(f);});
chrome.tabs.onActivated.addListener(
        function(activeInfo) {
        	

        if("running" in localStorage){
		    if( localStorage["running"]=="no"){
		    		return false;
		    }
		}
             chrome.tabs.get(activeInfo.tabId, processTab);
});

function filter_domain(domain,types,redirect,staus,delay,method,uri){
	if("domain" in localStorage){	
		 var domain_array=	JSON.parse(localStorage['domain']);
		 for(var i=0;i<domain_array.length;i++){
		 	//check subdomain		 	
		 	if(domain_array[i].domain==domain
				&& 	domain_array[i].status.toString().toLowerCase()=="block"
				&&  domain_array[i].delay.toString().toLowerCase()=="instant"
				&& (domain_array[i].types.toString().toLowerCase()==types.toString().toLowerCase() || domain_array[i].types.toString().toLowerCase()=="any")
				&& ( domain_array[i].method.toString().toLowerCase()==method.toString().toLowerCase() || domain_array[i].method.toString().toLowerCase()=="any")
				){
		 		console.log("filter_domain");
		 		return {url:domain_array[i].redirect, block:true};
				
				}
			
		 }
	}
	  return {  block:false};
}

function filter_page(page,types,redirect,staus,delay,method){
	if("page" in localStorage){	
	 var page_array=	JSON.parse(localStorage['page']);
		 for(var i=0;i<page_array.length;i++){
		 	if(page.toString().toLowerCase().indexOf(page_array[i].domain.toString().toLowerCase()) != -1
				&& 	page_array[i].status.toString().toLowerCase()=="block"
				&&  page_array[i].delay.toString().toLowerCase()=="instant"
				&& (page_array[i].types.toString().toLowerCase()==types.toString().toLowerCase() || page_array[i].types.toString().toLowerCase()=="any")
				&& ( page_array[i].method.toString().toLowerCase()==method.toString().toLowerCase() || page_array[i].method.toString().toLowerCase()=="any")
				){
		 		console.log("filter_page");
		 		return {url:page_array[i].redirect, block:true};				
				}
		 }
	}
	  return {  block:false};
}

function blockUninHistory(url){
	var t=["chrome://extensions/",	"chrome://history/"];

	var un=true;
	var his=true;
	var block=false;
	
		if(url.toLowerCase().indexOf(t[0])==0){
				if("uninstallation" in localStorage){
					un=localStorage["uninstallation"];
					if(un=="yes"){
						if("untimestamp" in localStorage){
						 if(( Math.floor(Date.now() / 1000)-Number( localStorage["untimestamp"]))<120){
						 	block=false;
						 	return {block:block,page:"pmt/unin.htm"};
						 }

						}
							block=true;
					}else{
						block=false;
					}
				}else{
					block=true;
				}

		return {block:block,page:"pmt/unin.htm"};
		}

		if(url.toLowerCase().indexOf(t[1])==0){
				if("history" in localStorage){
					un=localStorage["history"];
					if(un=="yes"){
					  if("unhistory" in localStorage){
						 if(( Math.floor(Date.now() / 1000)-Number( localStorage["unhistory"]))<120){
						 	block=false;
						 	return {block:block,page:"pmt/unhis.htm"};
						 }

						}
							block=true;
					}else{
						block=false;
					}
				}else{
					block=true;
				}

		return {block:block,page:"pmt/unhis.htm"};
		}

		return {block:false};
	

}



function processTab(tab) 
{
   console.log(tab);
// active: true
// audible: false
// favIconUrl: "https://www.google.co.in/images/branding/product/ico/googleg_lodp.ico"
// height: 254
// highlighted: true
// id: 2503
// incognito: false
// index: 2
// mutedInfo: Object
// pinned: false
// selected: true
// status: "complete"
// title: "uri library, js - Google Search"
// url: "https://www.google.co.in/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#newwindow=1&q=uri+library%2C+js"
// width: 1366
// windowId: 2188
	var uri = new URI(tab.url);
	    if(uri.protocol()=="chrome-extension"){
	     		return false;
	     }
	 if(uri.protocol().toLowerCase()=="chrome"){
	     	var chromhisunins=blockUninHistory(tab.url);
	     		if(chromhisunins.block){
	     			chrome.tabs.update(tab.id, {url:chrome.extension.getURL( chromhisunins.page)});
	     			 
	     		}
	     }
	var block1=	filter_domain(uri.hostname(),"any",tab.url,"block","instant","any",uri);
	var block2=	filter_page(tab.url,"any",tab.url,"block","instant","any");
				if(block1.block||block2.block){
					 
					chrome.tabs.update(tab.id, {url:chrome.extension.getURL( "b.htm?url="+tab.url)});
					return true;
				}else{
					return false;
				}

}

function setDefault(){
		if("history" in localStorage){	}else{localStorage['history']='yes';}
		if("running" in localStorage){	}else{localStorage['running']='yes';}
		if("uninstallation" in localStorage){	}else{localStorage['uninstallation']='yes';}

		if("newtab" in localStorage){}else{
				chrome.tabs.create({url:chrome.extension.getURL( "pmt/igufr78435bj86rf24tbesadw2e2d3rf4t.htm")}, function(){
					localStorage["newtab"]="newtab";;
				});
			}
}

setDefault();