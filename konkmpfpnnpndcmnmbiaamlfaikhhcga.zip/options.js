

//block between time

function bbt(){
	var from_hour="00";
	var from_min ="00";
	var to_hour  ="00";
	var to_min   ="00";
	
	if("bbttime" in localStorage){
	 var ob= new Object();
	 ob.fh=from_hour;//document.getElementById
	 ob.fm=from_min;
	 ob.th=to_hour;
	 ob.tm=to_min;
	 localStorage["bbttime"] = JSON.stringify(ob);
	  
	}else{

	 var ob= new Object();
	 ob.fh=from_hour;
	 ob.fm=from_min;
	 ob.th=to_hour;
	 ob.tm=to_min;
	 localStorage["bbttime"] = JSON.stringify(ob);

	}
}
 

function savedomain(n,redirect,types,status,delay,method){
	 var uri = new URI(n);
	 
     if(uri.protocol()=="chrome-extension"){
     	return {status:false,message:"chrome-extension is not allowed."};
     }
	 if(uri.protocol()==""){

	 	n="http://"+n;
	 }
	  var uri = new URI(n);
	 if(uri.hostname().toString().toLowerCase().indexOf("jasatoko")!=-1||uri.domain().toString().toLowerCase().indexOf("jasatoko")!=-1){
	 	return {status:false,message:"You cannot block jasatoko.com."};
	 }

	
	var domain_array= new Array();
	 var redirectdomain=(redirectdomain==null)?"b.html":redirect;
	 var ob= new Object();
	 ob.domain= uri.hostname();
	 ob.redirect=redirectdomain;
     ob.types=(types==null)?"any":types;
	 ob.status=(status==null)?"block":status;
	 ob.delay=(delay==null)?"instant":delay;
	 //ob.subdomain=(subdomain==null)?false:true;	 
	 ob.method=(method==null)?"any":method;

	 if("domain" in localStorage){
	 if(compareValue(JSON.parse(localStorage['domain']),[ob])){
	 	return {status:false,message:"This website is already added, please review all added list."};
	 }
	}



	if("domain" in localStorage){	
	 var domain_array=	JSON.parse(localStorage['domain']);
	 domain_array.push(ob);
	 localStorage["domain"] = JSON.stringify(domain_array);
	  
	}else{
	 domain_array.push(ob);
	 localStorage["domain"] = JSON.stringify(domain_array);
	}

  return {status:true,message:"This website is  added successfully."};
}

function savepagelink(n,redirect,types,status,delay,method,blockallsubdomain){
	 if(n.indexOf("chrome-extension://")==0){
     	return {status:false,message:"chrome-extension is not allowed."};
     }

    if(n.toString().toLowerCase().indexOf("jasatoko")!=-1){
	 	return {status:false,message:"You cannot block anything with term jasatoko."};
	 }
	var domain_array= new Array();
	 var redirectdomain=(redirectdomain==null)?"b.html":redirect;
	 var ob= new Object();
	 ob.domain= n;
	 ob.redirect=redirectdomain;
	 ob.types=(types==null)?"any":types;
	 ob.status=(status==null)?"block":status;
	 ob.delay=(delay==null)?"instant":delay;
	 ob.method=(method==null)?"any":method;
	 ob.blockallsubdomain=(blockallsubdomain==null)?true:blockallsubdomain;
    
    if("page" in localStorage){
	 if(compareValue(JSON.parse(localStorage['page']),[ob])){
	 	return {status:false,message:"This website is already added, please review all added list."};
	 }
	}
	if("page" in localStorage){	
	 var domain_array=	JSON.parse(localStorage['page']);
	 domain_array.push(ob);
	 localStorage["page"] = JSON.stringify(domain_array);
	  
	}else{
	 domain_array.push(ob);
	 localStorage["page"] = JSON.stringify(domain_array);
	}
	return {status:true,message:"This website is  added successfully."};
}


function isSaved(n){
	var domain_array= new Array();
	var found= false;
	var domain_array= JSON.parse(localStorage['domain']);
    for (i = 0; i < domain_array.length; i++) { 
    	
    	if(domain_array[i].domain==n){
    			found= true;
    	}
	}
	return found;
}

 function compareValue(functionArray ,functionCompare)
                               {
        /*
              var functionArray = [{
                                             "domain":"web.facebook.com",
                                             "redirect":"b.html",
                                            "types":"any",
                                            "status":"block",
                                            "delay":"instant",
                                            "method":"POST"
                                            },
                                             {
                                               "domain":"web.facebook.com",
                                             "redirect":"b.html",
                                            "types":"any",
                                            "status":"block",
                                            "delay":"instant",
                                            "method":"POST"
                                           }];
                              var functionCompare =[{
                                               "domain":"web.facebook.com",
                                             "redirect":"b.html",
                                            "types":"any",
                                            "status":"9block",
                                            "delay":"instant",
                                            "method":"POST"
                                           }];   

       */                        
                                           var i=0;
                                           var j=0;
                                       
       while(i<functionArray.length)
                {
                		//&&functionArray[i].redirect==functionCompare[j].redirect
                        if(functionArray[i].domain==functionCompare[j].domain&&functionArray[i].types==functionCompare[j].types&&functionArray[i].status==functionCompare[j].status&&functionArray[i].delay==functionCompare[j].delay&&functionArray[i].method==functionCompare[j].method)
                                          {
                                          return true;
                                          }
                                   
                                            i++;
                                // document.write(functionArray[1].domain); 
                                // document.write(functionArray[0].domain); 
                              
                           }
                        return false;
}
                       //alert( compareValue()); 
                  
