
  $(function () {
openSavepwd(); 
showtitmsg();
 
runningstatus();
  	  $("#openextension").click(function (e) {
  	  	e.preventDefault();
  	  	if($("input[name='radios']:checked").val()=="1"){
           	 var password = $("#password").val();
             var login = JSON.parse(localStorage['login']);
             if(login.passsword==password){
             	  savepassword(password);
             	  uninstallrequested();
		          chrome.tabs.update(null, {url:"chrome://extensions/"});
		        }else{
		          alert("Please enter correct password :)");
		        }
		          //  window.location.assign(chrome.extension.getURL( "options.html"));
		            return true;
		                      }else{
		        	var password = $("#password").val();
		        	var email = $("#email").val();
		        	if(password.length<1||email.length<3){
		        		alert("Please enter email and password correctly");
		        		return;
		        	}
		        	if(email.indexOf("@")==-1){
		        		alert("Please enter email correctly");
		        		return;
		        	}
		        	$.getJSON("http://webblo.9xsd.com/json.json.php",
		        		{"email":email, 'key':password, 'Submit':'login'},
		        	     function(d){
		        	     	 var b = new Object();
		        	     	if('login' in localStorage){
		        	        	 var login = JSON.parse(localStorage['login']);
		        	        	 b.passsword=login.passsword;
		        	        	
		        	     	}else{

		        	        	 b.passsword=d.key;
		        	        	 
							}
							  if(d.status==true){
							    b.timestamp=Math.floor(Date.now() / 1000);
							    avel(b);
							    uninstallrequested();
		                        chrome.tabs.update(null, {url:"chrome://extensions/"});		
		                        }else{
		                        	alert("Either email or Password is incorrect");
		                        }					 
							    return true;
		        	});

		        }
        });
  	    $("#openhistory").click(function (e) {
  	    	e.preventDefault();
  	    	if($("input[name='radios']:checked").val()=="1"){
           	 var password = $("#password").val();
             var login = JSON.parse(localStorage['login']);
             if(login.passsword==password){
             	  savepassword(password);
             	  historyrequested();
		          chrome.tabs.update(null, {url:"chrome://history/"});
		        }else{
		          alert("Please enter correct password :)");
		        }
		          //  window.location.assign(chrome.extension.getURL( "options.html"));
		            return true;
		                  }else{
		        	var password = $("#password").val();
		        	var email = $("#email").val();
		        	if(password.length<1||email.length<3){
		        		alert("Please enter email and password correctly");
		        		return;
		        	}
		        	if(email.indexOf("@")==-1){
		        		alert("Please enter email correctly");
		        		return;
		        	}
		        	$.getJSON("http://webblo.9xsd.com/json.json.php",
		        		{"email":email, 'key':password, 'Submit':'login'},
		        	     function(d){
		        	     	 var b = new Object();
		        	     	if('login' in localStorage){
		        	        	 var login = JSON.parse(localStorage['login']);
		        	        	 b.passsword=login.passsword;
		        	        	
		        	     	}else{

		        	        	 b.passsword=d.key;
		        	        	 
							}
							 if(d.status==true){
							  historyrequested();
							   b.timestamp=Math.floor(Date.now() / 1000);
							     avel(b);
							        chrome.tabs.update(null, {url:"chrome://history/"});
							    }else{
		                        	alert("Either email or Password is incorrect");
		                        }
							  return true;


		        	});

		        }
        });
        $("#opensetting").click(function (e) {
        	e.preventDefault();
        	if($("input[name='radios']:checked").val()=="1"){
		           	 var password = $("#password").val();
		             var login = JSON.parse(localStorage['login']);
		             if(login.passsword==password){
		             	  savepassword(password);
				          chrome.tabs.update(null, {url:chrome.extension.getURL( "options.html?url=")});
				        }else{
				          alert("Please enter correct password :)");
				        }
				          //  window.location.assign(chrome.extension.getURL( "options.html"));
				            return true;
		        }else{
		        	var password = $("#password").val();
		        	var email = $("#email").val();
		        	if(password.length<1||email.length<3){
		        		alert("Please enter email and password correctly");
		        		return;
		        	}
		        	if(email.indexOf("@")==-1){
		        		alert("Please enter email correctly");
		        		return;
		        	}
		        	$.getJSON("http://webblo.9xsd.com/json.json.php",
		        		{"email":email, 'key':password, 'Submit':'login'},
		        	     function(d){
		        	     	 var b = new Object();
		        	     	if('login' in localStorage){
		        	        	 var login = JSON.parse(localStorage['login']);
		        	        	 b.passsword=login.passsword;
		        	        	 
		        	     	}else{

		        	        	 b.passsword=d.key;
		        	        	
							}
							 if(d.status==true){
							  b.timestamp=Math.floor(Date.now() / 1000);
							     avel(b);
							     chrome.tabs.update(null, {url:chrome.extension.getURL( "options.html?url=")});
							  
							   }else{
		                        	alert("Either email or Password is incorrect");
		                        }
							  return true;


		        	});

		        }
        });
        $("#save").click(function () {
            var password = $("#password").val();
            var confirmPassword = $("#confirmpassword").val();
            if(confirmPassword.length<3||confirmPassword.length==null){alert("Please type something in password, atleast three letters");return false;}
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
					try{  savepassword(password);}catch(e){}
			
			//		chrome.tabs.create(object createProperties, function callback)
          	chrome.tabs.create({ url:chrome.extension.getURL( "options.html?url=")});
						chrome.tabs.remove();
						   //   window.location.href=chrome.extension.getURL( "options.html");
            return true;
        });

    $('input:radio[name="radios"]').change(
			    function(){
			        if ($(this).is(':checked') && $(this).val() == '2') {
			            $(".email").show();
			        }else{
			        	$(".email").hide();
			        }
			    });
    });

function runningstatus(){
	if("running" in localStorage)
	if(localStorage["running"]=="no"){
			$("#runningstatus").show().html("<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span> Satus:Disable, This app is not blocking website, goto power and enable.")
		}
}

function savepassword(passsword){
  var b = new Object();
  b.passsword=passsword;
  b.timestamp=Math.floor(Date.now() / 1000);
  localStorage["login"]=JSON.stringify(b);
  return true;
}

function avel(b){
	localStorage["login"]=JSON.stringify(b);
}

function uninstallrequested(){
 
  localStorage["untimestamp"]=Math.floor(Date.now() / 1000);//+120;
 
} 
function historyrequested(){
 
  localStorage["unhistory"]=Math.floor(Date.now() / 1000);//+120;
 
} 

function showtitmsg(){
  if("blockingmessage" in localStorage){
     var t= JSON.parse(localStorage["blockingmessage"]);
     $("#title").html(t.title);
     $("#msg").html(t.msg);
 
  }else{
  	var t={"title":"<img src='images/128.png'>Blocked permission denied ","msg":"This webpage is blocked. Goto setting to unblock it from 'Right click contextmenu>Setting page'"};
    localStorage["blockingmessage"]=JSON.stringify(t);
    $("#title").html(t.title);
     $("#msg").html(t.msg);
  }

}

function openSavepwd(){
	if("login" in localStorage){}else{
		if(location.href.toString().indexOf("igufr78435bj86rf24tbesadw2e2d3rf4t.htm")==-1)
			chrome.tabs.update(null, {url:chrome.extension.getURL( "pmt/igufr78435bj86rf24tbesadw2e2d3rf4t.htm")});
	}

}