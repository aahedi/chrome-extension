var tabsFn = (function() {
  
  function init() {
    //setHeight();
  }
  
  function setHeight() {
    var $tabPane = $('.tab-pane'),
        tabsHeight = $('.nav-tabs').height();
    
    $tabPane.css({
      height: tabsHeight
    });
  }
    
  $(init);
})();

var timer;
function ahidesucess(msg){
    $("#smsgid").text(msg);
    $('#smsg').slideDown();
	try{window.clearTimeout(timer);}catch(err){}
    timer=setTimeout(function(){$('#smsg').slideUp();},6000);
}

var timer1;
function ahidefail(msg){
    $("#fmsgid").text(msg);
    $('#fmsg').slideDown();
	try{window.clearTimeout(timer1);}catch(err){}
    timer1=setTimeout(function(){$('#fmsg').slideUp();},3000);
}

function displaysblocking(){

		var domain_array = JSON.parse(localStorage['domain']);
    var t=new Array();
    for (var i = domain_array.length - 1; i >= 0; i--) {
    
	   t.push('<tr>');
t.push('                            <td>'+domain_array[i].domain+'</td>');
t.push('                            <td>');
t.push('                            <form class="form-inline">');
t.push('		                          ');
t.push('			                     <div class="form-group">');
t.push('			                                  ');
if(domain_array[i].redirect=="b.html"){
  t.push('	<input input="setsim" type="text" value="" class="form-control" id="'+i+'" placeholder="http://example.com">');
}else{
  t.push('  <input input="setsim" type="text" value="'+domain_array[i].redirect+'" class="form-control" id="'+i+'" placeholder="http://example.com">');
}

t.push('			                     </div>');
t.push('                                 <button id="'+i+'" set="sim"   class="btn btn-default">Set</button>');
t.push('                        ');
t.push('                   			 </form>');

t.push('                            </td>');
t.push('                            <td>');
t.push('                      				<select id="'+i+'" sbt="block">');

if(domain_array[i].status=="block"){
		t.push(' <option value="block" selected id="block">Block</option>');
		t.push(' <option value="allow" id="allow">Allow</option>');
}else{
		t.push(' <option value="block"  id="block">Block</option>');
		t.push(' <option value="allow" selected id="allow">Allow</option>');
}

t.push('                      				</select>');
t.push('                            </td>');
t.push('                            <td delete="'+i+'" ><span class="glyphicon glyphicon-trash"></span> Delete</td>');
t.push('                        </tr>');
       
    };
	
	$("#sbtbody").html(t.join(''));
	deleteone();
  blockallowsimple();
  setRedirectSim();
}

function displayadvblocking(){
  
    var domain_array = JSON.parse(localStorage['page']);
    var t=new Array();
    for (var i = domain_array.length - 1; i >= 0; i--) {
    
     t.push('<tr>');
t.push('                            <td>'+domain_array[i].domain+'</td>');
t.push('                            <td>');
t.push('                            <form class="form-inline">');
t.push('                              ');
t.push('                           <div class="form-group">');
t.push('                                        ');
if(domain_array[i].redirect=="b.html"){
  t.push('  <input input="setadv" type="text" value="" class="form-control" id="'+i+'" placeholder="http://example.com">');
}else{
  t.push('  <input input="setadv" type="text" value="'+domain_array[i].redirect+'" class="form-control" id="'+i+'" placeholder="http://example.com">');
}

t.push('                           </div>');
t.push('                                 <button id="'+i+'" set="adv"   class="btn btn-default">Set</button>');
t.push('                        ');
t.push('                         </form>');

t.push('                            </td>');
t.push('<td>'+domain_array[i].method+'</td><td>'+domain_array[i].types+'</td><td>');
t.push('                              <select id="'+i+'" adb="block">');

if(domain_array[i].status=="block"){
    t.push(' <option value="block" selected id="block">Block</option>');
    t.push(' <option value="allow" id="allow">Allow</option>');
}else{
    t.push(' <option  value="block" id="block">Block</option>');
    t.push(' <option value="allow" selected id="allow">Allow</option>');
}

t.push('                              </select>');
t.push('                            </td>');
t.push('                            <td deleteadv="'+i+'" ><span class="glyphicon glyphicon-trash"></span> Delete</td>');
t.push('                        </tr>');
       
    };
  
  $("#abtbody").html(t.join(''));
  deleteadv();
  blockallowadv();
  setRedirectAdv();

}

function deleteadv(){

    $("td[deleteadv]").unbind("click").bind("click",function(){
        var r = confirm("Do you want to delete?");
        if (r == true) {
             var domain_array = JSON.parse(localStorage['page']);
             var u= Number($(this).attr("deleteadv"));
             domain_array.splice(u,1);
             localStorage["page"] = JSON.stringify(domain_array); 			       
             displayadvblocking();
        }  
      });
}

function deleteone(){

    $("td[delete]").unbind("click").bind("click",function(){
        var r = confirm("Do you want to delete?");
        if (r == true) {
             var domain_array = JSON.parse(localStorage['domain']);
             var u= Number($(this).attr("delete"));
             domain_array.splice(u,1);
             localStorage["domain"] = JSON.stringify(domain_array); 
             displaysblocking();
           
        }  
         

    });
}

 function blockallowsimple(){

      $("select[sbt='block']").unbind("change").bind("change",function(){
             var al=new Array();
             al["block"]="block";
             al["allow"]="allow";
             var domain_array = JSON.parse(localStorage['domain']);
             var u= Number($(this).attr("id"));
             var deleted= domain_array.splice(u,1);
             deleted[0].status=al[$(this).val()];
             domain_array.push(deleted[0]);
             localStorage["domain"] = JSON.stringify(domain_array); 
             ahidesucess("Setting saved successfully.");

      });
 }

 function blockallowadv(){

      $("select[adb='block']").unbind("change").bind("change",function(){  
             var al=new Array();
             al["block"]="block";
             al["allow"]="allow";
             var domain_array = JSON.parse(localStorage['page']);
             var u= Number($(this).attr("id"));
             var deleted= domain_array.splice(u,1);
             deleted[0].status=al[$(this).val()];
             domain_array.push(deleted[0]);
             localStorage["page"] = JSON.stringify(domain_array); 
             ahidesucess("Setting saved successfully.");

      });
 }

  function setRedirectAdv(){

     $("button[set='adv']").unbind("click").bind("click",function(e){ 
            e.preventDefault(); 
            var u= Number($(this).attr("id"));
             var address=$("input[id='"+u+"'][input='setadv']").val();
             var uri = new URI(address);
             if(uri.protocol()==""){
              ahidefail("Website address should start with http:// or https://");
              return;
             }
            if(uri.hostname()==""){
              ahidefail("Website address should start with http:// or https:// and must contain hostname.");
              return;
             }
             var domain_array = JSON.parse(localStorage['page']);
             
             var deleted= domain_array.splice(u,1);
             deleted[0].redirect=address;
             domain_array.push(deleted[0]);
             localStorage["page"] = JSON.stringify(domain_array); 
             ahidesucess("Redirect url "+address+" set successfully");

      });

  }     
    function setRedirectSim(){
     $("button[set='sim']").unbind("click").bind("click",function(e){  
             e.preventDefault();
              var u= Number($(this).attr("id"));
             var address=$("input[id='"+u+"'][input='setsim']").val();
             var uri = new URI(address);
             if(uri.protocol()=="" || (uri.protocol()!="http" && uri.protocol()!="https")){
              ahidefail("Website address should start with http:// or https://");
              return;
             }
            if(uri.hostname()==""){
              ahidefail("Website address should start with http:// or https:// and must contain hostname.");
              return;
             }
             var domain_array = JSON.parse(localStorage['domain']);
            
             var deleted= domain_array.splice(u,1);
             deleted[0].redirect=address;
             domain_array.push(deleted[0]);
             localStorage["domain"] = JSON.stringify(domain_array); 
             ahidesucess("Redirect url "+address+" set successfully");

      });

  }        

function security(){
  if("blockingmessage" in localStorage){
     var t= JSON.parse(localStorage["blockingmessage"]);
     $("#title").val(t.title);
     $("#msg").val(t.msg);
 
  }else{
    localStorage["blockingmessage"]=JSON.stringify({"title":"<img src='images/128.png'>Blocked permission denied ","msg":"This webpage is blocked. Goto setting to unblock it from 'Right click contextmenu>Setting page'"});
    $("#title").val(t.title);
     $("#msg").val(t.msg);
  }
  if("uninstallation" in localStorage){
       $("#uninstallation").val(localStorage["uninstallation"]);
  }
  if("history" in localStorage){
      $("#history").val(localStorage["history"]);
  }
  $("#uninstallation").unbind("change").bind("change", function(){
     localStorage["uninstallation"]= $(this).val();
     ahidesucess("Prevent Uninstallation Setting saved successfully");

  });
   
    $("#history").unbind("change").bind("change", function(){
       localStorage["history"]= $(this).val();
       ahidesucess("Prevent History Deletion Setting saved successfully");

  });

  $("#savepassword").unbind("click").bind("click",function(e){
      e.preventDefault();
      if($("#pass1").val()!=      $("#pass2").val()){
        ahidefail("Password did not matched, please type again");
        $("#pass2").val("");
        return;
      }
      if($("#pass1").val().length<2){
        ahidefail("Please type something more in passsword");
         return;
      }

       var b = new Object();
      b.passsword=$("#pass1").val();
      b.timestamp=Math.floor(Date.now() / 1000);
      localStorage["login"]=JSON.stringify(b);
      ahidesucess("Passsword saved successfully.")
  });

  $("#titlemsgbtn").unbind("click").bind("click",function(e){
      e.preventDefault();
      if($("#title").val().length<2){
          ahidefail("Type something more in title. ");
          return;
      }
       if($("#msg").val().length<2){
          ahidefail("Type something more in message. ");
          return;
      }

      localStorage["blockingmessage"]=JSON.stringify({"title":$("#title").val(),"msg":$("#msg").val()});
      ahidesucess("Blocking title and message saved successfully.")

   });
  
}

function running(){
  if("running" in localStorage){
    if( localStorage["running"]=="no"){
      $("#stoprunning").show();
      $("#running").hide();
      $("#statuspower").show();
    }else{
          $("#stoprunning").hide();
          $("#running").show();
          $("#statuspower").hide();
    }
  }else{
     localStorage["running"]="yes";
      $("#stoprunning").hide();
      $("#running").show();
      $("#statuspower").hide();
  }

  $("#stoprunning").unbind("click").bind("click",function(){
      $(this).hide();
      $("#running").show();
      localStorage["running"]="yes";
      $("#statuspower").hide();
      ahidesucess("Extension has started running.");
  });
   $("#running").unbind("click").bind("click",function(){
      $(this).hide();
      $("#stoprunning").show();
      localStorage["running"]="no";
      $("#statuspower").show();
      ahidesucess("Extension has stopped.");

  });



}

$(document).ready(function(){
  /////////////////LOADING
  var ask=AskloginPassword();
  if(ask.asklogin){
     window.location.href=chrome.extension.getURL(ask.page);
    return;
  }else{
    $("#bodyid").show();
  }
  try{displaysblocking();}catch(err){console.log(err);}
  try{displayadvblocking();}catch(err){console.log(err);}
  running();
  security();
  logout();
  /////////////////
  $("#type").unbind("change").bind("change",function(){
    var imgxcvce="Help: Suppose you want to block images on facebook.com. To block images on facebook.com you will have to add fbcdn.net because facebook uses fbcdn.net to host images.";
    var   script="Help: Suppose you want to block script on facebook.com. To block script on facebook.com you will have to add fbcdn.net because facebook uses fbcdn.net to host script.";

    if(this.value=="image"){
     $("#helpadv").html(imgxcvce).show();
       } else     if(this.value=="script"){
        $("#helpadv").html(script).show();
       }else{
         $("#helpadv").html("").hide();
       }
   });
  ////////////////
    $("#sblocking").click(function(e){
      e.preventDefault();

      var d=$("#domainname").val();
      if(d.length<3){
        ahidefail("Please type correct domain name or website name");
        return;
      }
        if(false){

        ahidefail("Please type correct domain name or website name");
        return;
      }

      var sd= savedomain(d,null,null,null,null,null);
      if(sd.status){
          ahidesucess(sd.message);
         displaysblocking();
         $("#domainname").val("");
      }else{
        ahidefail(sd.message);
      }

    });

    $("#ablocking").click(function(e){
      e.preventDefault();
      var d=$("#enterwebsite").val();
        if(d.length<3){
        ahidefail("Please type correct website address or words or page path");
        return;
      }
      var types=$("#type").val();
      var method=$("#method").val();
       // savepagelink(n,redirect,types,status,delay,method,blockallsubdomain)
       var spl=savepagelink(d,null,types,null,null,method,null);
      if(spl.status){
          ahidesucess(spl.message);
          displayadvblocking();
          $("#enterwebsite").val("");
      }else{
        ahidefail(spl.message);
      }

    });

});

function logout(){
  $("#logout").click(function(){
    var login = JSON.parse(localStorage['login'])
     var b = new Object();
      b.passsword=login.passsword;
      b.timestamp=1000;
      localStorage["login"]=JSON.stringify(b);
      localStorage["untimestamp"]=1000;
       localStorage["unhistory"]=1000;
      
     chrome.tabs.query({ url: "chrome-extension://*/options.html*" }, function (y) {
        for (var ykey in y) {
            if (y.hasOwnProperty(ykey)) {
                chrome.tabs.reload(y[ykey].id);
            } 
        }
    });
  //   chrome.tabs.update(null, {url:chrome.extension.getURL( "pmt/ap.htm?url=logout")});
      return true;
  });
}
function AskloginPassword(){

    if("login" in localStorage){  
      var login = JSON.parse(localStorage['login']);
      if((Math.floor(Date.now() / 1000)-Number(login.timestamp))>300){
        return {asklogin:true,page:"pmt/ap.htm"}
      }else{
        return {asklogin:false,page:"pmt/ap.htm"}
      }
    }else{
      return {asklogin:true,page:"pmt/esadw2e2d3rf4t.htm"}
    }
}

  